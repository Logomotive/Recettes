# Resources

A curated list of Pizza recipes and resources.

- [Jeff Varasano's Famous New York Pizza Recipe](http://www.varasanos.com/PizzaRecipe.htm)
- [The Physics of baking good Pizza](https://arxiv.org/pdf/1806.08790.pdf)
